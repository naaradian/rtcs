#ifndef __arp_h__
#define __arp_h__
/*HEADER****************************************************************
************************************************************************
***
*** Copyright (c) 1992-2003 ARC International
*** All rights reserved
***
*** This software embodies materials and concepts which are
*** confidential to ARC International and is made available solely
*** pursuant to the terms of a written license agreement with
*** ARC International.
***
*** File: arp.h
***
*** Comments:
***      Address Resolution Protocol definitions.
***
************************************************************************
*END*******************************************************************/

#include "ip_prv.h"


/***************************************
**
** Prototypes
**
*/

extern uint_32 ARP_init
(
   void
);

extern uint_32 ARP_open
(
   IP_IF_PTR      if_ptr      /* [IN] IP interface structure */
);

extern uint_32 ARP_close
(
   IP_IF_PTR      if_ptr      /* [IN] IP interface structure */
);

extern void ARP_service
(
   RTCSPCB_PTR    pcb_ptr     /* [IN] received packet */
);

extern uint_32 ARP_resolve
(
   IP_IF_PTR      if_ptr,     /* [IN] IP interface structure */
   RTCSPCB_PTR    pcb_ptr,    /* [IN] packet to send */
   _ip_address    isrc,       /* [IN] source address */
   _ip_address    idest       /* [IN] destination address */
);

extern boolean ARP_do_proxy
(
   IP_IF_PTR      iflocal,    /* [IN] the local interface */
   _ip_address    iplocal     /* [IN] the IP address to test */
);

#endif
/* EOF */

#ifndef __udp_h__
#define __udp_h__
/*HEADER****************************************************************
************************************************************************
***
*** Copyright (c) 1992-2003 ARC International
*** All rights reserved
***
*** This software embodies materials and concepts which are
*** confidential to ARC International and is made available solely
*** pursuant to the terms of a written license agreement with
*** ARC International.
***
*** File: udp.h
***
*** Comments:  This file contains the User Datagram Protocol definitions.
***            For more details, refer to RFC768.
***
************************************************************************
*END*******************************************************************/


/***************************************
**
** Constants
**
*/

/*
** UDP Open Options
*/
#define UDPOPT_CHKSUM_RX   0x0001      /* Option to bypass UDP checksum on Rx */
#define UDPOPT_CHKSUM_TX   0x0002      /* Option to bypass UDP checksum on Tx */
#define UDPOPT_NOBLOCK     0x0004      /* Option to send non-blocking         */


/***************************************
**
** Type definitions
**
*/


/*
** UDP Channel Block for listeners
*/
struct ucb_parm;
struct MCB;
typedef struct UCB {

   struct UCB _PTR_        NEXT;
   uint_32                 SOCKET;

   /* local UDP port */
   uint_16                 PORT;
   uint_16                 PCOUNT;

   void (_CODE_PTR_ SERVICE)(RTCSPCB_PTR, struct UCB _PTR_);

   /*
   ** Queue of incoming packets
   */
   RTCSPCB_PTR    PHEAD;
   RTCSPCB_PTR    PTAIL;

   /*
   ** Queue of waiting receive requests
   */
   struct ucb_parm _PTR_   RHEAD;
   struct ucb_parm _PTR_   RTAIL;

   /* Checksum bypass on reception */
   boolean        BYPASS_RX;

   /* Checksum bypass on transmission */
   boolean        BYPASS_TX;

   /* Non-blocking mode */
   boolean        NONBLOCK_RX;
   boolean        NONBLOCK_TX;

   /* local IP address, usually INADDR_ANY */
   _ip_address    IPADDR;

   /* list of joined multicast groups */
   struct MCB _PTR_        MCB_PTR;
   uint_32 (_CODE_PTR_     IGMP_LEAVEALL)(struct MCB _PTR_ _PTR_);

   /*
   ** Determines if a connection failure keeps the ucb's local IP,
   ** or if it resets it to INADDR_ANY
   */
   boolean        KEEP_IPADDR;

   /* Remote IP address and port when connected. (0 when not connected) */
   _ip_address    REMOTE_HOST;
   uint_16        REMOTE_PORT;
   uint_16        RESERVED0;

} UCB_STRUCT, _PTR_ UCB_STRUCT_PTR;

/*
** UDP parameters
*/
typedef struct ucb_parm {
   TCPIP_PARM              COMMON;
   struct ucb_parm _PTR_   NEXT;
   UCB_STRUCT_PTR          ucb;
   void (_CODE_PTR_        udpservice)(RTCSPCB_PTR, UCB_STRUCT_PTR);
   _ip_address             ipaddress;
   uint_16                 udpport;
   uint_16                 udpflags;
   pointer                 udpptr;
   uint_32                 udpword;
} UDP_PARM, _PTR_ UDP_PARM_PTR;


/***************************************
**
** Prototypes
**
*/

extern uint_32 UDP_init
(
   void
);

extern void UDP_open    (UDP_PARM_PTR);
extern void UDP_bind    (UDP_PARM_PTR);
extern void UDP_connect (UDP_PARM_PTR);
extern void UDP_close   (UDP_PARM_PTR);
extern void UDP_send    (UDP_PARM_PTR);
extern void UDP_receive (UDP_PARM_PTR);
extern void UDP_getopt  (UDP_PARM_PTR);
extern void UDP_setopt  (UDP_PARM_PTR);

extern uint_32 UDP_openbind_internal
(
   uint_16              localport,
   void (_CODE_PTR_     service)(RTCSPCB_PTR, UCB_STRUCT_PTR),
   UCB_STRUCT_PTR _PTR_ ucb
);

extern uint_32 UDP_close_internal
(
   UCB_STRUCT_PTR       ucb
);

extern uint_32 UDP_send_internal
(
   UCB_STRUCT_PTR       ucb,        /* [IN] UDP layer context      */
   _ip_address          srcaddr,    /* [IN] source IP address      */
   _ip_address          destaddr,   /* [IN] destination IP address */
   uint_16              destport,   /* [IN] destination UDP port   */
   RTCSPCB_PTR          pcb_ptr,    /* [IN] packet to send         */
   uint_32              flags       /* [IN] optional flags         */
);

extern uint_32 UDP_send_IF
(
   UCB_STRUCT_PTR,
   pointer,
   uint_16,
   RTCSPCB_PTR
);

extern void UDP_service
(
   RTCSPCB_PTR,
   pointer
);

extern void UDP_process
(
   RTCSPCB_PTR,
   UCB_STRUCT_PTR
);


#endif
/* EOF */

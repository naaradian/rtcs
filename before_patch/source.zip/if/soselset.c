/*HEADER****************************************************************
************************************************************************
***
*** Copyright (c) 1992-2003 ARC International
*** All rights reserved
***
*** This software embodies materials and concepts which are
*** confidential to ARC International and is made available solely
*** pursuant to the terms of a written license agreement with
*** ARC International.
***
*** File: soselset.c
***
*** Comments:  This file contains the RTCS_selectset() implementation.
***
************************************************************************
*END*******************************************************************/

#include <rtcs.h>
#include "rtcs_prv.h"
#include "socket.h"
#include "tcpip.h"


/*FUNCTION*-------------------------------------------------------------
*
* Function Name   : RTCS_selectset
* Returned Value  : socket handle
* Comments  :  Wait for data or connection requests on any socket
*      in a specified set.
*
*END*-----------------------------------------------------------------*/

uint_32 RTCS_selectset
   (
      pointer     sockset,
         /* [IN] set of sockets to block on */
      uint_32     size,
         /* [IN] size of sockset */
      uint_32     timeout
         /* [IN] specifies the maximum amount of time to wait for data */
   )
{ /* Body */
   SOCKSELECT_PARM   parms;
   uint_32           error;

   parms.sock_ptr   = sockset;
   parms.sock_count = size;
   parms.timeout    = timeout;
   error = RTCSCMD_issue(parms, SOCK_selectset);
   if (error) return RTCS_SOCKET_ERROR;

   return parms.sock;

} /* Endbody */


/*FUNCTION*-------------------------------------------------------------
*
* Function Name   : SOCK_selectset
* Parameters      :
*
*     _rtcs_taskid      owner       not used
*     uint_32 _PTR_     sock_ptr    [IN] array of socket handles
*     uint_32           sock_count  [IN] size of socket array
*     uint_32           timeout     [IN] timeout, 0=forever, -1=none
*     uint_32           sock        [OUT] socket with activity
*
* Comments  :  Wait for data or connection requests on any socket
*      owned by this task.
*
*END*-----------------------------------------------------------------*/

void SOCK_selectset
   (
      SOCKSELECT_PARM_PTR  parms
   )
{ /* Body */
   uint_32 _PTR_  socket_array;
   uint_32        i;

   /* check every socket in the supplied array */
   socket_array = parms->sock_ptr;
   for (i=0; i<parms->sock_count; i++) {

      if (SOCK_select_activity((SOCKET_STRUCT_PTR)socket_array[i])) {
         break;
      } /* Endif */

   } /* Endfor */

   if (i < parms->sock_count) {
      parms->sock = socket_array[i];
      RTCSCMD_complete(parms, RTCS_OK);
      return;
   } /* Endif */

   if (parms->timeout == (uint_32)-1) {
      parms->sock = 0;
      RTCSCMD_complete(parms, RTCS_OK);
      return;
   } /* Endif */

   parms->owner = 0;
   SOCK_select_block(parms);

} /* Endbody */


/* EOF */
